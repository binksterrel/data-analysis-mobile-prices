# data-analysis-mobile-prices
Analyse critique et audit d'un jeu de données sur les prix des mobiles, prouvant son incohérence.
